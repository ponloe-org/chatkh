'use strict';

/**
 * Minimal Chatwoot API v1 client used by the Telegram bridge.
 * Auth: agent bot / user API access token via `api_access_token` header.
 */

class ChatwootClient {
  constructor({ baseUrl, accountId, accessToken, inboxId }) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.accountId = accountId;
    this.accessToken = accessToken;
    this.inboxId = inboxId;
  }

  get configured() {
    return Boolean(this.baseUrl && this.accountId && this.accessToken && this.inboxId);
  }

  async api(path, { method = 'GET', body } = {}) {
    const res = await fetch(`${this.baseUrl}/api/v1/accounts/${this.accountId}${path}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        api_access_token: this.accessToken,
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Chatwoot ${method} ${path} -> ${res.status}: ${text.slice(0, 300)}`);
    }
    return res.json().catch(() => ({}));
  }

  async findOrCreateContact({ identifier, name }) {
    const search = await this.api(`/contacts/search?q=${encodeURIComponent(identifier)}`);
    const existing = (search.payload || []).find((c) => c.identifier === identifier);
    if (existing) return existing;

    const created = await this.api('/contacts', {
      method: 'POST',
      body: { inbox_id: Number(this.inboxId), identifier, name },
    });
    // API may return {payload:{contact:{...}}} or the contact directly
    return created?.payload?.contact || created?.contact || created;
  }

  async findOrCreateConversation({ contactId, sourceId }) {
    const list = await this.api(`/contacts/${contactId}/conversations`);
    const open = (list.payload || []).find((c) => c.status === 'open' || c.status === 'pending');
    if (open) return open;

    const created = await this.api('/conversations', {
      method: 'POST',
      body: { source_id: sourceId, inbox_id: Number(this.inboxId), contact_id: contactId },
    });
    return created?.payload || created;
  }

  async createIncomingMessage(conversationId, content) {
    return this.api(`/conversations/${conversationId}/messages`, {
      method: 'POST',
      body: { content, message_type: 'incoming' },
    });
  }

  /**
   * One-call helper used by the Telegram webhook handler.
   */
  async deliverInboundMessage({ telegramChatId, senderName, content }) {
    const identifier = `telegram_${telegramChatId}`;
    const contact = await this.findOrCreateContact({ identifier, name: senderName });
    const conversation = await this.findOrCreateConversation({
      contactId: contact.id,
      sourceId: identifier,
    });
    await this.createIncomingMessage(conversation.id, content);
    return { contactId: contact.id, conversationId: conversation.id };
  }
}

module.exports = { ChatwootClient };
