'use strict';

const Fastify = require('fastify');
const cors = require('@fastify/cors');
const QRCode = require('qrcode');

const khmer = require('./khmer');
const { buildKhqrPayload } = require('./khqr');
const { ChatwootClient } = require('./chatwoot');
const { DifyClient } = require('./dify');

const PORT = Number(process.env.PORT || 4000);
const HOST = '0.0.0.0';

const app = Fastify({
  logger: { level: process.env.LOG_LEVEL || 'info' },
  bodyLimit: 1024 * 1024, // 1MB — webhook payloads are small
});

// ---- CORS (browser callers; Telegram webhooks are server-to-server) --------
const allowedOrigins = (process.env.CORS_ORIGINS || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);
app.register(cors, {
  origin: allowedOrigins.length ? allowedOrigins : false,
  methods: ['GET', 'POST', 'OPTIONS'],
});

// ---- Service clients ---------------------------------------------------------
const chatwoot = new ChatwootClient({
  baseUrl: process.env.CHATWOOT_BASE_URL || 'http://chatwoot-rails:3000',
  accountId: process.env.CHATWOOT_ACCOUNT_ID || '1',
  accessToken: process.env.CHATWOOT_API_ACCESS_TOKEN || '',
  inboxId: process.env.CHATWOOT_INBOX_ID || '',
});

const dify = new DifyClient({
  baseUrl: process.env.DIFY_API_BASE || 'http://dify-api:5001/v1',
  apiKey: process.env.DIFY_API_KEY || '',
});

// ---- Routes ------------------------------------------------------------------

app.get('/health', async () => ({
  status: 'ok',
  service: 'cambodia-gateway',
  uptime_seconds: Math.round(process.uptime()),
  integrations: {
    chatwoot: chatwoot.configured,
    dify: dify.configured,
    telegram: Boolean(process.env.TELEGRAM_BOT_TOKEN),
    khqr: Boolean(process.env.KHQR_BAKONG_ACCOUNT_ID),
  },
}));

/**
 * Khmer NLP preprocessing endpoint.
 * POST /nlp/khmer/preprocess { "text": "..." }
 */
app.post('/nlp/khmer/preprocess', async (req, reply) => {
  const { text } = req.body || {};
  if (!text || typeof text !== 'string') {
    return reply.code(400).send({ error: 'body.text (string) is required' });
  }
  if (text.length > 20000) {
    return reply.code(413).send({ error: 'text exceeds 20000 characters' });
  }
  return khmer.preprocess(text);
});

/**
 * KHQR generation (Bakong / EMVCo).
 * POST /khqr/generate { "amount": 2.5, "currency": "USD", "billNumber": "INV-001" }
 * Returns the raw payload plus a scannable PNG data URL.
 */
app.post('/khqr/generate', async (req, reply) => {
  try {
    const body = req.body || {};
    const payload = buildKhqrPayload({
      bakongAccountId: body.bakongAccountId || process.env.KHQR_BAKONG_ACCOUNT_ID,
      merchantName: body.merchantName || process.env.KHQR_MERCHANT_NAME,
      merchantCity: body.merchantCity || process.env.KHQR_MERCHANT_CITY,
      merchantId: body.merchantId || process.env.KHQR_MERCHANT_ID,
      terminalLabel: body.terminalLabel || process.env.KHQR_TERMINAL_LABEL,
      amount: body.amount,
      currency: body.currency || 'KHR',
      billNumber: body.billNumber,
      mobileNumber: body.mobileNumber,
      storeLabel: body.storeLabel,
    });
    const qrDataUrl = await QRCode.toDataURL(payload, { margin: 2, width: 512 });
    return { payload, qrDataUrl };
  } catch (err) {
    req.log.warn({ err }, 'KHQR generation failed');
    return reply.code(400).send({ error: err.message });
  }
});

/**
 * Dify AI bridge — ask the RAG/knowledge engine directly.
 * POST /ai/ask { "query": "...", "user": "telegram_123", "conversationId": "" }
 */
app.post('/ai/ask', async (req, reply) => {
  if (!dify.configured) {
    return reply.code(503).send({ error: 'Dify integration is not configured (DIFY_API_KEY)' });
  }
  const { query, user = 'gateway-anonymous', conversationId = '', inputs } = req.body || {};
  if (!query) return reply.code(400).send({ error: 'body.query is required' });
  try {
    return await dify.chat({ query, user, conversationId, inputs });
  } catch (err) {
    req.log.error({ err }, 'Dify call failed');
    return reply.code(502).send({ error: 'AI engine unavailable' });
  }
});

/**
 * Telegram webhook receiver.
 * Configure with Bot API setWebhook:
 *   url=https://api.example.kh/webhooks/telegram
 *   secret_token=$TELEGRAM_WEBHOOK_SECRET
 *
 * Flow: verify secret -> normalize + preprocess Khmer text -> forward the
 * message into Chatwoot as an incoming customer message.
 */
app.post('/webhooks/telegram', async (req, reply) => {
  const expectedSecret = process.env.TELEGRAM_WEBHOOK_SECRET;
  if (expectedSecret) {
    const got = req.headers['x-telegram-bot-api-secret-token'];
    if (got !== expectedSecret) {
      req.log.warn('Telegram webhook: invalid secret token');
      return reply.code(401).send({ ok: false });
    }
  }

  const update = req.body || {};
  const message = update.message || update.edited_message;
  const text = message?.text || message?.caption;

  // Acknowledge immediately (Telegram expects a fast 200); process async.
  reply.code(200).send({ ok: true });

  if (!message || !text) return;
  if (!chatwoot.configured) {
    req.log.warn('Telegram update received but Chatwoot is not configured — dropped');
    return;
  }

  try {
    const nlp = khmer.preprocess(text);
    const sender = message.from || {};
    const senderName =
      [sender.first_name, sender.last_name].filter(Boolean).join(' ') ||
      sender.username ||
      `tg_${message.chat.id}`;

    // Annotate the message with extracted entities so agents see them inline.
    const annotations = [];
    if (nlp.entities.phones.length) annotations.push(`📞 ${nlp.entities.phones.join(', ')}`);
    if (nlp.entities.amounts.length) {
      annotations.push(
        `💰 ${nlp.entities.amounts.map((a) => `${a.value} ${a.currency || ''}`.trim()).join(', ')}`
      );
    }
    const content =
      nlp.normalized + (annotations.length ? `\n\n—\n[auto] ${annotations.join(' | ')}` : '');

    const result = await chatwoot.deliverInboundMessage({
      telegramChatId: message.chat.id,
      senderName,
      content,
    });
    req.log.info({ ...result, language: nlp.language }, 'Telegram message delivered to Chatwoot');
  } catch (err) {
    req.log.error({ err }, 'Failed to deliver Telegram message to Chatwoot');
  }
});

// ---- 404 + error handlers -----------------------------------------------------
app.setNotFoundHandler((req, reply) => {
  reply.code(404).send({ error: 'not found' });
});
app.setErrorHandler((err, req, reply) => {
  req.log.error({ err }, 'unhandled error');
  reply.code(err.statusCode || 500).send({ error: 'internal error' });
});

app.listen({ port: PORT, host: HOST }).catch((err) => {
  app.log.error(err);
  process.exit(1);
});
