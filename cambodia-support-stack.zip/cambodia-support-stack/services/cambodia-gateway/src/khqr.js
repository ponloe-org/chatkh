'use strict';

/**
 * KHQR payload builder — Bakong (National Bank of Cambodia) flavor of EMVCo QR.
 *
 * Implements the EMVCo Merchant-Presented QR payload with Bakong's
 * merchant-account-information template (tag 29, GUI "kh.gov.nbc.bakong")
 * and CRC16-CCITT (poly 0x1021, init 0xFFFF) checksum per the KHQR spec.
 *
 * Always validate generated QRs against the Bakong app / your acquiring
 * bank's sandbox before going live. Individual accounts typically need
 * only sub-tags 00 (GUI) + 01 (Bakong account ID); merchant accounts may
 * require additional fields issued by your acquiring bank.
 */

const GUI_BAKONG = 'kh.gov.nbc.bakong';

const CURRENCY_CODES = { KHR: '116', USD: '840' };

function tlv(id, value) {
  const v = String(value);
  return `${id}${v.length.toString().padStart(2, '0')}${v}`;
}

function crc16(payload) {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

/**
 * Build a KHQR payload string.
 *
 * @param {object} opts
 * @param {string} opts.bakongAccountId  e.g. "yourname@aba" (required)
 * @param {string} opts.merchantName     max 25 chars (required)
 * @param {string} opts.merchantCity     (required)
 * @param {number} [opts.amount]         omit for open-amount (static) QR
 * @param {'KHR'|'USD'} [opts.currency]  default KHR
 * @param {string} [opts.merchantId]     acquirer-issued merchant ID
 * @param {string} [opts.billNumber]     invoice/reference, max 25 chars
 * @param {string} [opts.mobileNumber]
 * @param {string} [opts.storeLabel]
 * @param {string} [opts.terminalLabel]
 */
function buildKhqrPayload(opts) {
  const {
    bakongAccountId,
    merchantName,
    merchantCity,
    amount,
    currency = 'KHR',
    merchantId,
    billNumber,
    mobileNumber,
    storeLabel,
    terminalLabel,
  } = opts || {};

  if (!bakongAccountId) throw new Error('KHQR: bakongAccountId is required');
  if (!merchantName) throw new Error('KHQR: merchantName is required');
  if (!merchantCity) throw new Error('KHQR: merchantCity is required');
  if (merchantName.length > 25) throw new Error('KHQR: merchantName max 25 chars');
  if (currency && !CURRENCY_CODES[currency]) {
    throw new Error(`KHQR: currency must be one of ${Object.keys(CURRENCY_CODES).join(', ')}`);
  }

  // 29 — Merchant Account Information (Bakong template)
  let merchantAccount = tlv('00', GUI_BAKONG) + tlv('01', bakongAccountId);
  if (merchantId) merchantAccount += tlv('02', merchantId);

  let payload = '';
  payload += tlv('00', '01');                       // Payload Format Indicator
  payload += tlv('01', amount ? '12' : '11');       // 12 = dynamic, 11 = static
  payload += tlv('29', merchantAccount);            // Bakong account
  payload += tlv('52', '0000');                     // MCC (unspecified)
  payload += tlv('53', CURRENCY_CODES[currency]);   // 116 = KHR, 840 = USD
  if (amount != null && amount !== '') {
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) throw new Error('KHQR: amount must be > 0');
    payload += tlv('54', currency === 'KHR' ? String(Math.round(amt)) : amt.toFixed(2));
  }
  payload += tlv('58', 'KH');                       // Country
  payload += tlv('59', merchantName);
  payload += tlv('60', merchantCity);

  // 62 — Additional Data Field Template
  let additional = '';
  if (billNumber) additional += tlv('01', String(billNumber).slice(0, 25));
  if (mobileNumber) additional += tlv('02', String(mobileNumber).slice(0, 25));
  if (storeLabel) additional += tlv('03', String(storeLabel).slice(0, 25));
  if (terminalLabel) additional += tlv('07', String(terminalLabel).slice(0, 25));
  if (additional) payload += tlv('62', additional);

  // 63 — CRC (computed over payload + "6304")
  payload += '6304';
  payload += crc16(payload);

  return payload;
}

module.exports = { buildKhqrPayload, crc16, GUI_BAKONG, CURRENCY_CODES };
