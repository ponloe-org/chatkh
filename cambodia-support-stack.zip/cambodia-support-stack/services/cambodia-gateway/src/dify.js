'use strict';

/**
 * Minimal Dify service-API client (blocking chat-messages).
 */

class DifyClient {
  constructor({ baseUrl, apiKey }) {
    this.baseUrl = (baseUrl || '').replace(/\/$/, '');
    this.apiKey = apiKey;
  }

  get configured() {
    return Boolean(this.baseUrl && this.apiKey);
  }

  async chat({ query, user, conversationId = '', inputs = {} }) {
    const res = await fetch(`${this.baseUrl}/chat-messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        inputs,
        query,
        response_mode: 'blocking',
        conversation_id: conversationId,
        user,
      }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Dify chat-messages -> ${res.status}: ${text.slice(0, 300)}`);
    }
    const data = await res.json();
    return {
      answer: data.answer,
      conversationId: data.conversation_id,
      messageId: data.message_id,
      usage: data.metadata?.usage || null,
    };
  }
}

module.exports = { DifyClient };
