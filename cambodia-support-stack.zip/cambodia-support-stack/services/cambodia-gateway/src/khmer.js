'use strict';

/**
 * Khmer NLP preprocessing utilities.
 *
 * What this does (deterministic, zero-dependency, runs in <1ms):
 *   - Unicode NFC normalization (Khmer vowel/coeng ordering issues)
 *   - Khmer digit -> ASCII digit conversion (០១២៣៤៥៦៧៨៩ -> 0-9)
 *   - Zero-width space (U+200B) cleanup, whitespace collapsing
 *   - Language detection (km / en / mixed) by Unicode block ratio
 *   - Lightweight ZWSP segmentation around non-Khmer tokens & punctuation
 *   - Entity extraction: Cambodian phone numbers, KHR/USD amounts
 *
 * For full dictionary-based Khmer word segmentation, plug a segmenter
 * (e.g. a CRFSeg/khmersegment model) into `segmentKhmer()` — the output
 * contract stays the same.
 */

const KHMER_DIGITS = {
  '០': '0', '១': '1', '២': '2', '៣': '3', '៤': '4',
  '៥': '5', '៦': '6', '៧': '7', '៨': '8', '៩': '9',
};

// Khmer block U+1780–U+17FF plus Khmer Symbols U+19E0–U+19FF
const KHMER_CHAR = /[ក-៟᧠-᧿]/;

function convertKhmerDigits(text) {
  return text.replace(/[០-៩]/g, (d) => KHMER_DIGITS[d] || d);
}

function normalize(text) {
  if (typeof text !== 'string') return '';
  return convertKhmerDigits(text)
    .normalize('NFC')
    // Remove zero-width chars that break matching/search (common in Khmer text)
    .replace(/[​‌‍﻿]/g, '')
    // Collapse runs of whitespace
    .replace(/\s+/g, ' ')
    .trim();
}

function detectLanguage(text) {
  if (!text) return 'unknown';
  const letters = [...text].filter((c) => /\S/.test(c));
  if (letters.length === 0) return 'unknown';
  const khmerCount = letters.filter((c) => KHMER_CHAR.test(c)).length;
  const ratio = khmerCount / letters.length;
  if (ratio > 0.6) return 'km';
  if (ratio < 0.1) return 'en';
  return 'mixed';
}

/**
 * Conservative ZWSP segmentation: inserts U+200B at script boundaries
 * (Khmer <-> Latin/digit) and around punctuation. Does NOT attempt
 * dictionary word-splitting — safe to feed downstream to LLM prompts,
 * full-text search indexing, and logging pipelines.
 */
function segmentKhmer(text) {
  if (!text) return { segmented: '', tokens: [] };
  const segmented = text
    // boundary: Khmer <-> non-Khmer (letters/digits)
    .replace(/([ក-៟])([A-Za-z0-9])/g, '$1​$2')
    .replace(/([A-Za-z0-9])([ក-៟])/g, '$1​$2')
    // around Khmer punctuation ។ ៕ ៖ and common ASCII punctuation
    .replace(/([។៕៖!?,.])/g, '​$1​')
    .replace(/​{2,}/g, '​')
    .trim();
  const tokens = segmented.split(/[​\s]+/).filter(Boolean);
  return { segmented, tokens };
}

function extractEntities(text) {
  const entities = { phones: [], amounts: [] };
  if (!text) return entities;

  // Cambodian mobile numbers: 0xx xxx xxx(x) — digits already converted
  const phoneMatches = text.match(/(?:\+?855|0)\s?\d{2}\s?\d{3}\s?\d{3,4}/g);
  if (phoneMatches) {
    entities.phones = [...new Set(phoneMatches.map((p) => p.replace(/\s/g, '')))];
  }

  // Amounts: 12.50$, $12.50, 5000៛, 5,000 KHR / USD
  const amountMatches = text.match(
    /(?:\$\s?\d[\d,]*(?:\.\d{1,2})?|\d[\d,]*(?:\.\d{1,2})?\s?(?:៛|KHR|USD|\$))/gi
  );
  if (amountMatches) {
    entities.amounts = amountMatches.map((raw) => {
      const currency = /៛|KHR/i.test(raw)
        ? 'KHR'
        : /\$|USD/i.test(raw)
          ? 'USD'
          : null;
      const value = parseFloat(raw.replace(/[^\d.]/g, ''));
      return { raw: raw.trim(), value, currency };
    });
  }

  return entities;
}

/**
 * Full preprocessing pipeline for an inbound customer message.
 */
function preprocess(text) {
  const normalized = normalize(text);
  const { segmented, tokens } = segmentKhmer(normalized);
  return {
    original: text,
    normalized,
    segmented,
    tokens,
    language: detectLanguage(normalized),
    entities: extractEntities(normalized),
    length: normalized.length,
  };
}

module.exports = { normalize, detectLanguage, segmentKhmer, extractEntities, preprocess };
