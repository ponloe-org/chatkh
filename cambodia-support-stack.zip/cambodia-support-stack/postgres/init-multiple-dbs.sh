#!/bin/bash
# Creates isolated databases + least-privilege users for each service.
# Runs once on first boot of the postgres container (empty data dir).
set -euo pipefail

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres <<-SQL
  CREATE USER chatwoot WITH PASSWORD '${CHATWOOT_DB_PASSWORD}';
  CREATE DATABASE chatwoot OWNER chatwoot;

  CREATE USER dify WITH PASSWORD '${DIFY_DB_PASSWORD}';
  CREATE DATABASE dify OWNER dify;
  CREATE DATABASE dify_plugin OWNER dify;
SQL

# Extensions must be installed per-database by the superuser.
for db in chatwoot dify dify_plugin; do
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$db" <<-SQL
    CREATE EXTENSION IF NOT EXISTS vector;
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
    CREATE EXTENSION IF NOT EXISTS pg_trgm;
SQL
done

echo "init-multiple-dbs: databases chatwoot, dify, dify_plugin created."
