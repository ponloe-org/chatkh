# Cambodia Omnichannel Customer Support & AI Stack

Self-hosted, enterprise-grade support platform localized for Cambodia:

| Component | Purpose | URL (example) |
|---|---|---|
| **Chatwoot CE v4.16** | Omnichannel inbox (web, Telegram, FB, email) | `https://chat.example.kh` |
| **Dify v1.11** | AI workflow & RAG knowledge engine | `https://ai.example.kh` |
| **cambodia-gateway** | Telegram webhooks, Khmer NLP preprocessing, KHQR (Bakong) QR generation, Dify bridge | `https://api.example.kh` |
| **PostgreSQL 16 + pgvector** | One shared instance, three isolated databases, least-privilege users | internal |
| **Redis 7** | Shared cache/queue; logical DB separation (0=Chatwoot, 1=Dify, 2=plugin daemon) | internal |
| **Nginx + Certbot** | TLS termination, WebSockets, CORS, rate limiting, auto-renew | :80/:443 |

Resource ceilings are tuned for a **4 vCPU / 8 GB RAM** VPS (limits sum ≈ 7.5 GB, actual idle usage ≈ 2–3 GB). Vector search runs on **pgvector** inside the shared Postgres instead of a separate Weaviate container, saving ~500 MB RAM.

## Folder structure

```
├── docker-compose.yml
├── .env.example
├── README.md
├── nginx/
│   ├── default.conf              # envsubst template (domains come from .env)
│   └── init-letsencrypt.sh       # one-time SSL bootstrap
├── postgres/
│   └── init-multiple-dbs.sh      # creates chatwoot/dify/dify_plugin DBs + users
└── services/
    └── cambodia-gateway/
        ├── Dockerfile
        ├── package.json
        └── src/
            ├── index.js          # Fastify server + routes
            ├── khmer.js          # Khmer NLP preprocessing
            ├── khqr.js           # KHQR (EMVCo/Bakong) payload builder + CRC16
            ├── chatwoot.js       # Chatwoot API client
            └── dify.js           # Dify API client
```

## Prerequisites

- Ubuntu 22.04/24.04 VPS, Docker Engine 24+ with Compose v2 (`docker compose version`)
- Three DNS **A records** pointing to the VPS: `chat.`, `ai.`, `api.` (your domain)
- Ports 80/443 open in the firewall

## Deployment

```bash
# 1. Get the stack onto the VPS
cd /opt && unzip cambodia-support-stack.zip && cd cambodia-support-stack

# 2. Configure
cp .env.example .env
# Generate secrets:
openssl rand -hex 64   # -> CHATWOOT_SECRET_KEY_BASE
openssl rand -hex 32   # -> DIFY_SECRET_KEY
openssl rand -hex 16   # -> DIFY_SANDBOX_API_KEY and DIFY_PLUGIN_DAEMON_KEY
nano .env              # domains, passwords, Telegram token, KHQR merchant info

# 3. Start the data + app services (Chatwoot migrations run automatically)
docker compose up -d postgres redis
docker compose up -d chatwoot-migrate        # wait for it to exit 0
docker compose up -d

# 4. Issue SSL certificates (run ONCE; nginx is already running from step 3)
chmod +x nginx/init-letsencrypt.sh
./nginx/init-letsencrypt.sh
# Test with LETSENCRYPT_STAGING=1 first to avoid rate limits.

# 5. Auto-renewal reload — add to root crontab (crontab -e):
#    17 3 * * *  cd /opt/cambodia-support-stack && docker compose exec nginx nginx -s reload
```

## Post-deploy wiring (5 minutes)

1. **Chatwoot admin**: open `https://chat.example.kh`, create the first user (becomes admin).
2. **Gateway → Chatwoot**: in Chatwoot, create an **API inbox** (Settings → Inboxes → Add → API). Copy your **access token** (Profile → Access Token), the **account ID** and **inbox ID** from the URLs, put them in `.env` (`CHATWOOT_API_ACCESS_TOKEN`, `CHATWOOT_ACCOUNT_ID`, `CHATWOOT_INBOX_ID`), then `docker compose up -d --force-recreate cambodia-gateway`.
3. **Dify**: open `https://ai.example.kh/install`, create the admin, connect your model provider (Settings → Model Provider). Create a Chat/RAG app, upload Khmer/English knowledge docs, then copy its API key (App → API Access) into `DIFY_APP_API_KEY`.
4. **Telegram webhook** (register once per bot):
   ```bash
   curl "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/setWebhook" \
     -d "url=https://api.example.kh/webhooks/telegram" \
     -d "secret_token=$TELEGRAM_WEBHOOK_SECRET"
   ```

## Verification

```bash
# Containers healthy + resource usage (should stay well under 8 GB)
docker compose ps
docker stats --no-stream

# Config valid + env substituted correctly
docker compose config --quiet && echo "compose OK"

# End-to-end health checks
curl -s https://api.example.kh/health | jq          # all integrations true
curl -sI https://chat.example.kh | head -1          # HTTP/2 200
curl -sI https://ai.example.kh    | head -1

# WebSockets (Chatwoot ActionCable) — expect "101 Switching Protocols"
curl -i -N -H "Connection: Upgrade" -H "Upgrade: websocket" \
  -H "Sec-WebSocket-Key: SGVsbG8sIHdvcmxkIQ==" -H "Sec-WebSocket-Version: 13" \
  https://chat.example.kh/cable | head -5

# Khmer NLP preprocessing
curl -s -X POST https://api.example.kh/nlp/khmer/preprocess \
  -H 'Content-Type: application/json' \
  -d '{"text":"សួស្តី! តម្លៃ ៥០០០៛ ទូទាត់បានទេ? ទូរស័ព្ទ ០១២៣៤៥៦៧៨"}' | jq

# KHQR generation (scan the QR with Bakong/your banking app to validate)
curl -s -X POST https://api.example.kh/khqr/generate \
  -H 'Content-Type: application/json' \
  -d '{"amount":5000,"currency":"KHR","billNumber":"INV-0001"}' | jq '.payload'

# Logs
docker compose logs -f cambodia-gateway
docker compose logs -f chatwoot-rails | tail -50
```

## Backup

```bash
# Databases
docker compose exec postgres pg_dump -U postgres chatwoot    | gzip > backup-chatwoot-$(date +%F).sql.gz
docker compose exec postgres pg_dump -U postgres dify        | gzip > backup-dify-$(date +%F).sql.gz
docker compose exec postgres pg_dump -U postgres dify_plugin | gzip > backup-dify-plugin-$(date +%F).sql.gz

# Volumes (uploads, Dify storage, certs)
docker run --rm -v cambodia-support_chatwoot_storage:/v -v "$PWD":/b alpine tar czf /b/backup-chatwoot-storage-$(date +%F).tgz -C /v .
docker run --rm -v cambodia-support_dify_storage:/v      -v "$PWD":/b alpine tar czf /b/backup-dify-storage-$(date +%F).tgz -C /v .
```

## Production hardening notes

- **Pin & patch**: images are pinned (`chatwoot/chatwoot:v4.16.1`, `langgenius/dify-*:1.11.4`). Check release pages before upgrades; test with a staging compose project first.
- **pgvector**: Dify uses `VECTOR_STORE=pgvector` on the shared Postgres. For >100k document chunks, move Dify to a dedicated vector DB.
- **KHQR**: the builder implements the EMVCo/Bakong payload with CRC16. Validate QRs with the Bakong app and confirm merchant fields with your acquiring bank (ABA, ACLEDA, Wing…) before production payments.
- **Khmer segmentation**: `khmer.js` ships deterministic normalization + heuristic ZWSP segmentation. For dictionary-grade segmentation, plug a trained segmenter into `segmentKhmer()` — the API contract won't change.
- **Secrets**: never commit `.env`. Consider `docker compose` with Docker secrets or an external vault for the DB passwords.
- **Scaling**: when the VPS outgrows 8 GB, split Postgres/Redis to a second host first, then Dify worker.
