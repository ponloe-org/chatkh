#!/usr/bin/env bash
# =============================================================================
# init-letsencrypt.sh — bootstrap Let's Encrypt certificates
# Solves the chicken-and-egg problem: nginx needs certs to start with TLS,
# certbot needs nginx on :80 to answer ACME challenges.
# Order: create ALL dummy certs -> start nginx -> request each real cert.
#
# Usage:  chmod +x nginx/init-letsencrypt.sh && ./nginx/init-letsencrypt.sh
# Prereq: .env filled in; DNS A records for all 3 domains -> this VPS.
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."

set -a; source ./.env; set +a
DOMAINS=("${CHATWOOT_DOMAIN}" "${DIFY_DOMAIN}" "${GATEWAY_DOMAIN}")
EMAIL="${LETSENCRYPT_EMAIL:-admin@${CHATWOOT_DOMAIN}}"
STAGING="${LETSENCRYPT_STAGING:-0}"   # set to 1 while testing (avoids rate limits)

STAGING_ARG=()
if [ "${STAGING}" = "1" ]; then STAGING_ARG=(--staging); fi

echo "### Step 1/4 — creating dummy certificates for all domains ..."
for DOMAIN in "${DOMAINS[@]}"; do
  docker compose run --rm --no-deps --entrypoint sh certbot -c "
    mkdir -p /etc/letsencrypt/live/${DOMAIN} &&
    openssl req -x509 -nodes -newkey rsa:2048 -days 1 \
      -keyout /etc/letsencrypt/live/${DOMAIN}/privkey.pem \
      -out    /etc/letsencrypt/live/${DOMAIN}/fullchain.pem \
      -subj '/CN=localhost'"
done

echo "### Step 2/4 — starting nginx (dummy certs allow TLS config to load) ..."
docker compose up -d --force-recreate nginx

echo "### Step 3/4 — requesting real certificates ..."
for DOMAIN in "${DOMAINS[@]}"; do
  docker compose run --rm --no-deps --entrypoint certbot certbot certonly \
    --webroot -w /var/www/certbot \
    "${STAGING_ARG[@]}" \
    -d "${DOMAIN}" \
    --email "${EMAIL}" \
    --agree-tos --no-eff-email --force-renewal
done

echo "### Step 4/4 — reloading nginx with real certificates ..."
docker compose exec nginx nginx -s reload

echo "### Done. Certificates issued for: ${DOMAINS[*]}"
echo "### The certbot service renews every 12h; add this host cron to reload nginx after renewal:"
echo '    17 3 * * *  cd '"$(pwd)"' && docker compose exec nginx nginx -s reload'
